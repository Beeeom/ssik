#include<stdio.h>

int gugudan_sum() //��ȯ
{
	int sum = 0;
	for (int i = 2; i <= 9; i++)
	{
		for (int j = 1; j <= 9; j++)
			sum += (i * j);
	}
	return sum;
}
void q2_dan_print(int dan) //���
{
	for (int i = 1; i <= 9; i++)
		printf("%d x %d = %d\n", dan, i, dan * i);
}

void q3_gugu_god(int s, int e)//���
{
	for (int i = 2; i <= 9; i++)
	{
		for (int j = s; j <= e; j++) {
			printf("%d x %d =%d\n", i, j, i * j);
		}
	}
}
int q4_gugudan_sum(int s, int e)//��ȯ
{
	int sum = 0;
	for (int i = s; i <= e; i++)
	{
		for (int j = 1; j <= 9; j++)
		{
			printf("%d x %d = %d\n", i, j, i * j);
			sum += (i * j);
		}
	}
	return sum;
}

int main() 
{
	printf("q1 : %d", gugudan_sum());
	int dan;
	printf("\nq2\n");
	scanf_s("%d", &dan);
	q2_dan_print(dan);
	printf("\nq3 x ����� x��� �ұ��?");
	int start, end;
	scanf_s("%d %d", &start, &end);
	q3_gugu_god(start, end);
	int start_dan, end_dan;
	scanf_s("%d %d", &start_dan, &end_dan);
	printf("4����� : %d\n", q4_gugudan_sum(start_dan, end_dan));
	return 0;
}