#include<stdio.h>
void gugu()
{
	for (int i = 2; i <= 9; i++) {

		for (int j = 1; j <= 9; j++)
		{
			printf("%d x %d=%2d   ", i, j, i * j);
		}
		printf("\n");
	}
}

void gugudan()
{
	printf("�� �ܺ��� �� ��??");
	int dan_s, dan_e;
	scanf_s("%d %d", &dan_s, &dan_e);
	printf("x�� ���� x�����?");
	int x_s, x_e;
	scanf_s("%d %d", &x_s, &x_e);
	for (int i = dan_s; i <= dan_e; i++)
	{
		for (int j = x_s; j <= x_e; j++)
			printf("%d x %d = %d\n", i, j, i * j);

	}
}
int main()
{


	for (int i = 2; i <= 9; i++)
	{
		for (int j = 1; j <= 9; j++)
	{
			printf("%dx%d=%d\n", i, j, i * j);
		}
		printf("\n");
	}

	
	gugu();

	gugudan();

	return 0;
}