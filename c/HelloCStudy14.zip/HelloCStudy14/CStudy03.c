#include<stdio.h>
void Swap(int*a, int* b, int* c)
{
	int temp = *a;
	*a = *b;
	*b = *c;
	*c = temp;
}

int main()
{
	int a = 1; 
	int b = 2;
	int c = 3;
	int aa, bb, cc;
	int aa2, bb2, cc2;
	scanf_s("%d %d %d", &aa, &bb, &cc);
	 aa2 = aa;
	 bb2 = bb;
	 cc2 = cc;
	 printf("%d %d %d\n", aa, bb, cc);
	 Swap(&aa, &bb, &cc);
	 printf("%d %d %d\n", aa, bb, cc);

	for (int i = 0; i < 1; i++)
	{
		(aa2 != aa && bb2 != bb && cc2 != cc);
		printf("%d %d %d\n", aa, bb, cc);
		Swap(&a, &b, &c);
		Swap(&a, &b, &c);
		printf("a=%d,b=%d,c=%d\n", a, b, c);
	}

	/*Swap(&a, &b, &c);
	printf("a=%d,b=%d,c=%d\n", a, b, c);
	Swap(&a, &b, &c);
	printf("a=%d,b=%d,c=%d\n", a, b, c);
	Swap(&a, &b, &c);
	printf("a=%d,b=%d,c=%d\n", a, b, c);*/
	return 0;
}