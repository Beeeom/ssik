#include<stdio.h>

int gugu(int a)
	{
	int sum = 0;
	printf("%d\n", a);
	for (int j = 1; j <= 9; j++) {
		printf("%d x %d =%d\n", a, j, a * j);
		sum = sum + a * j;

	}
	return sum;
}


int main()

{
	int num;
	scanf_s("%d",&num);
	printf("�� ��%d",gugu(num));

	return 0;
}
