char* season(int month)
{
		printf("%s", "asdfsd");
	switch (month)
	{
	case 12:
	case 1:
	case 2:
	return "�ܿ�";
	case 3:
	case 4:
	case 5:
		return "��";
	case 6:
	case 7:
	case 8:
		return "����";
	case 9:
	case 10:
	case 11:
		return "����";


	default: return "����";
		break;
	}
}
#include<stdio.h>
int length(char* str)
{
	int len = 0;
	while (str[len] != '\0')
		len++;
	return len;
}
int main()
{

	printf("%s\n", season(8));
	printf("%s\n", season(13));
	printf("%s\n", season(10));
	printf("%s\n", season(1));
	printf("%s\n", season(5));
	printf("%d\n", length("abcd1234"));
	printf("%d\n", length("abcd 123 4"));
	return 0;
}