#include<stdio.h>
//void printYourName(char n[])
void printYourName(char* n)
{
printf("����� �̸��� %s�Դϴ�.\n", n);

}
char* printABC()
{
	return "abc\n";
}
char* returnMyInfo()
{
	static char mbti[5];
	printf("mbti?");
	gets(mbti);
	return mbti;
}
char* rethrnMyMBTI(char* mbti)
{
	return mbti;
}
int main()
{
	printf("�̸� �Է�");
	char name[100];
	gets(name);
	printYourName(name);
	printf("%s", printABC());
	printf("%s\n", returnMyInfo());
	printf("%s\n", rethrnMyMBTI("ENFP"));
	printf("%s\n", rethrnMyMBTI(name));
	return 0;
}