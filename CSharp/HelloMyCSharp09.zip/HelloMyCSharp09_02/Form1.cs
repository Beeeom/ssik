﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloMyCSharp09_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView3.Columns.Add("name", "이름");
            dataGridView3.Columns.Add("gender", "성별");

            productBindingSource.Add(new Product() { Name = "감자", Price = 500 });
            productBindingSource.Add(new Product() { Name = "토마토", Price = 800 });
            productBindingSource.Add(new Product() { Name = "호박", Price = 1500 });

            //dataGridView5.Columns.Add("name", "이름");
            //dataGridView5.Columns.Add("hakbun", "학번");
            // dataGridView5.Columns.Add("gender", "성별");
           
        }

       

       

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView3.Rows.Add(textBox1.Text, textBox2.Text);
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<Product> products = new List<Product>();
            products.Add(new Product() { Name = "김치", Price =5000});
            products.Add(new Product() { Name = "시금치", Price =1500});
            products.Add(new Product() { Name = "감귤", Price =2500});

            dataGridView4.DataSource = null;
            dataGridView4.DataSource = products;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //dataGridView5.Rows.Add(textBox3.Text, textBox4.Text, textBox5.Text);
            studuntcsBindingSource.Add(new Studuntcs() { name = textBox3.Text, hakbun = textBox4.Text, gender = textBox5.Text });
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // for(int i = 0; i<studuntcsBindingSource.Count; i++)
            //{
            //   if ( (studuntcsBindingSource[i] as Studuntcs).name == "이범식" )
            //  {
            //     studuntcsBindingSource.Remove(studuntcsBindingSource[i]);
            //}
            // }

            int index = dataGridView5.CurrentCell.RowIndex;
            studuntcsBindingSource.Add(studuntcsBindingSource[index]);




        }

        private void button5_Click(object sender, EventArgs e)
        {
            int index = dataGridView5.CurrentCell.RowIndex;
            studuntcsBindingSource.Remove(studuntcsBindingSource[index]);
            studuntcsBindingSource.Add(new Studuntcs() { name = textBox3.Text, hakbun = textBox4.Text, gender = textBox5.Text });
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }
    }
}
