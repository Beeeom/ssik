﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp09_02
{
    public class Studuntcs
    {
        public string name { get; set; }
        public string hakbun { get; set; }
        public string gender { get; set; }
    }
}
