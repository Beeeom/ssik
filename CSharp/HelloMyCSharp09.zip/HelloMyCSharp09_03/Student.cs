﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp09_03
{
    public class Student
    {
        public string name { get; set; }
        public string hakbeon { get; set; }
        public string gender { get; set; }
    }
}
