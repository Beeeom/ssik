﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp08_03
{
    public class Android : IMyRobot
    {
        public void actCute()
        {
            System.Windows.Forms.MessageBox.Show("애교");
        }

        public void attacktarget()
        {
            System.Windows.Forms.MessageBox.Show("공격");
        }

        public void killTarget()
        {
            System.Windows.Forms.MessageBox.Show("죽여!");
        }

        public void printMessage(string message)
        {
            System.Windows.Forms.MessageBox.Show("삐리리릿");
        }

        public void protectMaster(string name)
        {
            System.Windows.Forms.MessageBox.Show(name+ "지켜!");
        }

        public void smile()
        {
            System.Windows.Forms.MessageBox.Show("씨익");
        }

        public void welCome()
        {
            System.Windows.Forms.MessageBox.Show("어서오고~");
        }
    }
}
