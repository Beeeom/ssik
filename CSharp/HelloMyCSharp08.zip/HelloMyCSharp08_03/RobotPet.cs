﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp08_03
{
    public class RobotPet : ICharming, IFight
    {
        public int age { get; set; }
        public void actCute()
        {
        System.Windows.Forms.MessageBox.Show("뿌잉뿌잉");
        }

        public void attacktarget()
        {
            System.Windows.Forms.MessageBox.Show("죽빵을 빵");
        }

        public void killTarget()
        {
            System.Windows.Forms.MessageBox.Show("목을 따불랑께");
        }

        public void protectMaster(string name)
        {
            System.Windows.Forms.MessageBox.Show(name+ "내 뒤에서시오!");
        }

        public void smile()
        {
            System.Windows.Forms.MessageBox.Show("ㅎㅎㅎㅎㅎㅎㅎ");
        }

        public void welCome()
        {
            System.Windows.Forms.MessageBox.Show("똥고를 보여준다");
        }
    }
}
