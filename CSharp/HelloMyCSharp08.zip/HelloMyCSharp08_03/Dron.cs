﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp08_03
{
    public class Dron : IFight
    {
        public int age { get; set; }
        public void attacktarget()
        {
        System.Windows.Forms.MessageBox.Show("몸통박치기");
        }

        public void killTarget()
        {
        System.Windows.Forms.MessageBox.Show("날개로 와롸롸롹");
        }

        public void protectMaster(string name)
        {
        System.Windows.Forms.MessageBox.Show(name +"뒤로오시오!");
        }
    }
}
