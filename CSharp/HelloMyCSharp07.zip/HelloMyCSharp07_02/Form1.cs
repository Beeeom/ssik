﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloMyCSharp07_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cat c = new Cat() { age = 10, Name = "야옹이" };
            c.eat();
            c.sleep();
            c.fight();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tiger t = new Tiger() { age = 100, Name = "호돌이" };
            t.sleep();
            t.eat();
            t.fight();

            ((Cat)t).eat();
            ((Cat)t).fight();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cat c = new Cat();
            c.Name = "헤라";
            c.age = 30;
            MessageBox.Show(c.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tiger t = new Tiger();
            t.Name = "호치";
            t.age = 100;
            MessageBox.Show(t.ToString());
        }
    }
}
