﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp07_02
{
    internal class Tiger : Cat
    {
        public new void eat()
        {
            System.Windows.Forms.MessageBox.Show
                ($"{Name} 호랑이는 무섭게 먹습니다.{age}살이에요.");
        }
        public override void fight()
        {
            System.Windows.Forms.MessageBox.Show
                ($"{age}실 {Name} 호랑이의 혈투 크헝~");
        }
        public override string ToString()
        {
            return $"이름 : {Name}, 나이:{age}";
           // return base.ToString();
        }
    }
}
