﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPCRoom
{
    public class PC_User
    {
        public string User_id { get; set; }
        public string Name { get; set; }
        public string Using_status { get; set; }
        public DateTime Start_time { get; set; }
        public string Use_time { get; set; }
        public string Late_time { get; set; }
        public string Seat_num { get; set; }
    }
}
