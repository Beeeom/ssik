﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp10_04
{
    public class Weather
    {
        public int hour { get; set; } //시간
        public string wf { get; set; } //날씨
        public double temp { get; set; } //온도
    }
}
