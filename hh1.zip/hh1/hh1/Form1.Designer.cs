﻿namespace hh1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1Dashboard = new System.Windows.Forms.Button();
            this.button2Sellers = new System.Windows.Forms.Button();
            this.button3Calender = new System.Windows.Forms.Button();
            this.button4Tasks = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button4Tasks);
            this.panel1.Controls.Add(this.button3Calender);
            this.panel1.Controls.Add(this.button2Sellers);
            this.panel1.Controls.Add(this.button1Dashboard);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 638);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.checkBox4);
            this.panel2.Controls.Add(this.checkBox3);
            this.panel2.Controls.Add(this.checkBox2);
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(200, 348);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1042, 290);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 100);
            this.panel3.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(227, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total Sales";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 72F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, -15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 117);
            this.label2.TabIndex = 3;
            this.label2.Text = "m";
            // 
            // button1Dashboard
            // 
            this.button1Dashboard.FlatAppearance.BorderSize = 0;
            this.button1Dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1Dashboard.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1Dashboard.ForeColor = System.Drawing.Color.White;
            this.button1Dashboard.Image = ((System.Drawing.Image)(resources.GetObject("button1Dashboard.Image")));
            this.button1Dashboard.Location = new System.Drawing.Point(3, 140);
            this.button1Dashboard.Name = "button1Dashboard";
            this.button1Dashboard.Size = new System.Drawing.Size(197, 108);
            this.button1Dashboard.TabIndex = 3;
            this.button1Dashboard.Text = "Dashboard";
            this.button1Dashboard.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1Dashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1Dashboard.UseVisualStyleBackColor = true;
            this.button1Dashboard.Click += new System.EventHandler(this.button1Dashboard_Click);
            // 
            // button2Sellers
            // 
            this.button2Sellers.FlatAppearance.BorderSize = 0;
            this.button2Sellers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Sellers.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2Sellers.ForeColor = System.Drawing.Color.White;
            this.button2Sellers.Image = ((System.Drawing.Image)(resources.GetObject("button2Sellers.Image")));
            this.button2Sellers.Location = new System.Drawing.Point(3, 254);
            this.button2Sellers.Name = "button2Sellers";
            this.button2Sellers.Size = new System.Drawing.Size(197, 108);
            this.button2Sellers.TabIndex = 3;
            this.button2Sellers.Text = "Sellers";
            this.button2Sellers.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2Sellers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2Sellers.UseVisualStyleBackColor = true;
            this.button2Sellers.Click += new System.EventHandler(this.button2Sellers_Click);
            // 
            // button3Calender
            // 
            this.button3Calender.FlatAppearance.BorderSize = 0;
            this.button3Calender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3Calender.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3Calender.ForeColor = System.Drawing.Color.White;
            this.button3Calender.Image = ((System.Drawing.Image)(resources.GetObject("button3Calender.Image")));
            this.button3Calender.Location = new System.Drawing.Point(3, 368);
            this.button3Calender.Name = "button3Calender";
            this.button3Calender.Size = new System.Drawing.Size(197, 108);
            this.button3Calender.TabIndex = 3;
            this.button3Calender.Text = "Calender";
            this.button3Calender.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3Calender.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button3Calender.UseVisualStyleBackColor = true;
            this.button3Calender.Click += new System.EventHandler(this.button3Calender_Click);
            // 
            // button4Tasks
            // 
            this.button4Tasks.FlatAppearance.BorderSize = 0;
            this.button4Tasks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4Tasks.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4Tasks.ForeColor = System.Drawing.Color.White;
            this.button4Tasks.Image = ((System.Drawing.Image)(resources.GetObject("button4Tasks.Image")));
            this.button4Tasks.Location = new System.Drawing.Point(2, 482);
            this.button4Tasks.Name = "button4Tasks";
            this.button4Tasks.Size = new System.Drawing.Size(197, 108);
            this.button4Tasks.TabIndex = 3;
            this.button4Tasks.Text = "Tasks";
            this.button4Tasks.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4Tasks.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button4Tasks.UseVisualStyleBackColor = true;
            this.button4Tasks.Click += new System.EventHandler(this.button4Tasks_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(229, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(627, 259);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(452, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tasks";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(680, 22);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(73, 38);
            this.button6.TabIndex = 3;
            this.button6.Text = "Monsh";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(570, 22);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(104, 38);
            this.button7.TabIndex = 3;
            this.button7.Text = "Six Monsh";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(491, 22);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(73, 38);
            this.button8.TabIndex = 3;
            this.button8.Text = "Year";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(776, 22);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(73, 38);
            this.button5.TabIndex = 3;
            this.button5.Text = "Week";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(325, 234);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(370, 59);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(199, 21);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "Lemon ispum is a dummy Text";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(370, 86);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(102, 21);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Text = "C# UI Design";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(370, 113);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(115, 21);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.Text = "BY BEOOOM sik";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(370, 140);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(122, 21);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.Text = "C# UI ACADEMY";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(190)))), ((int)(((byte)(0)))));
            this.panelLeft.Location = new System.Drawing.Point(206, 164);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(7, 72);
            this.panelLeft.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(41)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(1242, 638);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(120)))), ((int)(((byte)(138)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4Tasks;
        private System.Windows.Forms.Button button3Calender;
        private System.Windows.Forms.Button button2Sellers;
        private System.Windows.Forms.Button button1Dashboard;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panelLeft;
    }
}

