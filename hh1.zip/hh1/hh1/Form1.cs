﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hh1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void button1Dashboard_Click(object sender, EventArgs e)
        {
            panelLeft.Height = button1Dashboard.Height;
            panelLeft.Top = button1Dashboard.Top;
        }

        private void button2Sellers_Click(object sender, EventArgs e)
        {
            panelLeft.Height = button2Sellers.Height;
            panelLeft.Top = button2Sellers.Top;
        }

        private void button3Calender_Click(object sender, EventArgs e)
        {
            panelLeft.Top = button3Calender.Top;
            panelLeft.Height = button3Calender.Height;
        }

        private void button4Tasks_Click(object sender, EventArgs e)
        {
            panelLeft.Height = button4Tasks.Height;
            panelLeft.Top = button4Tasks.Top;
        }
    }
}
