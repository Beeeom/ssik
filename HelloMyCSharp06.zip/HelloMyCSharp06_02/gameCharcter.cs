﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp06_02
{
    internal class gameCharcter
    {
        public static string Count { get; internal set; }
    }
}
